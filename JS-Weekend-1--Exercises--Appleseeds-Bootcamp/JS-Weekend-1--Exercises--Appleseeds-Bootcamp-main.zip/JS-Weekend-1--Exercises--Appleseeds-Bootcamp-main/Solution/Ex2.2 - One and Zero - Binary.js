function Binar(arr) {
  console.log(parseInt(arr.join(""), 2));
}
//test
Binar([1, 0, 1, 1]);