function Boolean(bool) {
  console.log((bool === true ? "Yes \n" : "No"))
}
//test
Boolean(true);
Boolean(false);