function indPerimeter(length, width) {
  return (length + width) * 2;
}
//test
console.log(indPerimeter(6, 7));
console.log(indPerimeter(20, 10));
console.log(indPerimeter(2, 9));