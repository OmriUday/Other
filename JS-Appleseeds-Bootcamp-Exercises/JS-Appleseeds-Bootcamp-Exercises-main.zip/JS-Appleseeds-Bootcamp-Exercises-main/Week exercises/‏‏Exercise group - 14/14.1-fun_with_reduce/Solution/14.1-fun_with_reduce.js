const numbers = [1,2,3,4,5,6,7,8,9,10];
//1.
let maxnum = numbers.reduce((maxnum, num) => {
  if (maxnum < num) return num;
  return maxnum;
});
console.log(maxnum); //test

//2.
let sumEven = numbers
  .filter((num) => !(num % 2))
  .reduce((a, b) => {
    return a + b;
  });
console.log(sumEven); //test

//3.
let sumNum = numbers.reduce((tot, num) => {
  return tot + num;
});
let avg = sumNum / numbers.length;
console.log(avg); //test