function numberScore (num) {
  if ( 0<=num && num<=64) {
    console.log('scor of : "F" ');
  }
  else if ( 65<=num && num<=69) {
    console.log('scor of : "D" ');
  }
  else if ( 70<=num && num<=79) {
    console.log('scor of : "C" ');
  }
  else if ( 80<=num && num<=89) {
    console.log('scor of : "B" ');
  }
  else if ( 90<=num && num<=100) {
    console.log('scor of : "A" ');
  }
  else
    console.log('Invalid input');
}

console.log(numberScore(101));