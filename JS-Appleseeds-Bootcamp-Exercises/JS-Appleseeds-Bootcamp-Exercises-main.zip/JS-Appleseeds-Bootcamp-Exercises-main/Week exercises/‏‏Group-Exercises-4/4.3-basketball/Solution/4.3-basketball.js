////4.3////
///1,2,3)
const johnTeam = [89, 120, 103];
const mikeTeam = [116, 94, 123];

const johnAvg = (johnTeam[0] + johnTeam[1] + johnTeam [2]) / 3 ;

const mikeAvg = (mikeTeam[0] + mikeTeam[1] + mikeTeam [2]) / 3 ;

if (johnAvg > mikeAvg) {
  console.log("The avg of John Team per game is : " +johnAvg, "points", ' The avg of Mike Team per game is : ' +mikeAvg, "points", "It follows that the winning team of the 2 players is the team of - John ! ");
}
else if (johnAvg < mikeAvg) {
  console.log("The avg of John Team per game is : " +johnAvg, "points", ' The avg of Mike Team per game is : ' +mikeAvg, "points", "It follows that the winning team of the 2 players is the team of - Mike ! ");
}
else {
  console.log("The avg of John Team per game is : " +johnAvg, "points", ' The avg of Mike Team per game is : ' +mikeAvg, "points", "As a result, the two teams scored a number of identical points, so the result is equality!");
  }
///4,5)
const johnTeam = [89, 120, 103];
const mikeTeam = [116, 94, 123];
const maryTeam = [97, 134, 105];

const johnAvg = (johnTeam[0] + johnTeam[1] + johnTeam [2]) / 3 ;

const mikeAvg = (mikeTeam[0] + mikeTeam[1] + mikeTeam [2]) / 3 ;

const maryAvg = (maryTeam[0] + maryTeam[1] + maryTeam [2]) / 3 ;

if (johnAvg===mikeAvg && mikeAvg===maryAvg) {
  console.log("The avg of John Team per game is : " +johnAvg, "points", ' The avg of Mike Team per game is : ' +mikeAvg, "points", "The avg of John Team per game is : " +maryAvg, "points , As a result, the two teams scored a number of identical points, so the result is equality ! ");
}
else if (johnAvg > mikeAvg && johnAvg > maryAvg) {
  console.log("The avg of John Team per game is : " +johnAvg, "points", ' The avg of Mike Team per game is : ' +mikeAvg, "points", "The avg of John Team per game is : " +maryAvg, "points", "It follows that the winning team of the 3 players is the team of - John ! ");
}
else if (maryAvg < mikeAvg) {
  console.log("The avg of John Team per game is : " +johnAvg, "points", ' The avg of Mike Team per game is : ' +mikeAvg, "points", "The avg of John Team per game is : " +maryAvg, "points", "It follows that the winning team of the 3 players is the team of - Mike ! ");
}
else {
    console.log("The avg of John Team per game is : " +johnAvg, "points", ' The avg of Mike Team per game is : ' +mikeAvg, "points", "The avg of John Team per game is : " +maryAvg, "points", "It follows that the winning team of the 3 players is the team of - Mary ! ");
}