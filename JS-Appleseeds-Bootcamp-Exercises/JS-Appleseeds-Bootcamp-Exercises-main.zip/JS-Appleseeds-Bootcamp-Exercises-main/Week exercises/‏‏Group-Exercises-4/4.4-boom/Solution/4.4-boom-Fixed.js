////4.4////
function sevenBoom(n) {
  let y, check;
  for (let i = 1; i <= n; i++) {
    y = i, check = 1;               // Refresh checker
    if (i % 7 == 0) {               // Check Divided by 7
      while (y != 0) {              // Check there are 7 in number
        if (y % 10 == 7) {          // divided 7 && the is 7 in number (BOOM-BOOM)
          console.log("BOOM-BOOM");
          y = 0;
          check = 0;                // exit while
        }
        else {
          y = Math.floor(y / 10);
        }
      }
      if (check != 0) {              // just divided 7 (BOOM)
        console.log("BOOM");
      }
    }
    else {                          //Any other case without BOOM
      console.log(i);
    }
  }
}


//check//
sevenBoom(100);