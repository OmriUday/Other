////4.5////
function givenYear (num) {
  if (num % 4 === 0) {
    if (num % 100 != 0) {
      console.log("It is indeed a leap year");
    }
    else if (num % 400 === 0) {
      console.log("It is indeed a leap year");
    }
    else {
      console.log("This is not a leap year.");
    }
  }
  else {
    console.log("This is not a leap year.");
  }
}

givenYear(2100);
