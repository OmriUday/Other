////5.1////
///1,2,3
function countryToLiveIn(language, isIsland, population, country) {
  if (language === 'Hebrew' || 'English' && isIsland === 'flase' && population < 9420214 && country === Israel) {
    console.log('You should live in Israel');
  }
  else {
    console.log('Israel does not meet your criteria');
  }
}

//test
countryToLiveIn('Hebrew', 'false', 8000000, 'Israel');

///4,5)
function countryToLiveIn(language, isIsland, population, country) {
  if (language === 'Hebrew' || 'English' && isIsland === 'flase' && population < 9420214 && country === Israel) {
    console.log('You should live in Israel');
  }
  else {
    console.log('Israel does not meet your criteria');
  }
}

//test
countryToLiveIn('Turkish', 'false', 8000000, 'Israel');