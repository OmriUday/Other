///////5.3//////
// function passwordValidation ('pass') {
if ('pass'.length > 7) {
  console.log('Strong');
}
else {
  console.log('week');
}
}
//test
passwordValidation('ajkl');

function passwordValidation('pass') {
  switch ('pass') {
    case 'pass'.length > 7:
      console.log('Strong');
      break;
    case 'pass'.length < 7:
      console.log('Weak');
      break;
  }
}
//test
passwordValidation('asdfghjkl');



function advanced(pass) {
  if (pass.length > 7 && /[A-Z]/.test('pass') == true) {
    console.log('Very Strong');
  }
  else if {
    if(pass.length > 7 )
    console.log('Strong');
  }
  else if (pass.length < 7) {
    console.log('Weak');
  }
}
// //test
advanced('asd')