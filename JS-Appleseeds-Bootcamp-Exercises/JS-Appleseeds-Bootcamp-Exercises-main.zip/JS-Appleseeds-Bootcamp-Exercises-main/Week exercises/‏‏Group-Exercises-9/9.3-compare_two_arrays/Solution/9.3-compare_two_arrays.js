function compareArrays(arr1, arr2) {
  const longesArr = arr1, shortesArr = arr2;
  let check = 0;
  if (arr1 < arr2) {
    longesArr = arr2, shortesArr = arr1;
  }
  for (let i = 0; i < longesArr.length; i++) {
    check = 0;
    for (let j = 0; j < longesArr.length; j++) {
      if (shortesArr[j] === longesArr[i]) {
        console.log(shortesArr[j]);
        check = 1;
      }
    }
    if (check == 0) {
      console.log(false);
    }
  }
}
const food = ["Noodle", "Pasta", "Ice-cream", "Meat",
  "Cucumber", "Olives"];
const food1 = ["Fries", "Ice-cream", "Pizza", "Olives",
  "Hamburgers"];
//test
compareArrays(food, food1);
