function step(num) {
  let str = '';
  for (let i = 0; i < num; i++) {
    for (let j = 0; j <= i; j++) {
      str += '#';
    }
    console.log(str);
    str = '';
  }
}
//test
step(7);