function doubleValues(arr) {
  const newArr = arr.map(function (num) {
    return 2 * num;
  });
  return newArr;
}

function onlyEvenValues(arr) {
  const newArr = arr.forEach(function (num) {
    if (num % 2 != 0) {
      newArr.pop();
    }
  });
  return newArr;
}

function showFirstAndLast(arr) {
  const firstEndStr = [];
  for (let i = 0; i < arr.length; i++) {
    if (typeof arr[i] === "string") {
      firstEndStr.push(arr[i]);
      break;
    }
  }
}
