function callBack(str) {
  if (typeof str == 'string') {
    return 1;
  } else {
    return -1;
  }
}
function isString(str) {
  return callBack(str);
}
console.log(isString("Omri"));

function firstWordUpperCase(str, func) {
  let strtoarray = str.split(' ');
  strtoarray[0].toUpperCase()
  strtoarray.push((strtoarray[0].toUpperCase()));
  strtoarray.shift(strtoarray[0]);
  strtoarray.reverse();
  let str1 = strtoarray.toString();
  return func(str1)
}
console.log(firstWordUpperCase("Omri Uday", dashes));

function dashes(str1) {
  return str1.replace(",", "-")
}
function firstWordUpperCase(str, func) {
  let strtoarray = str.split(' ');
  strtoarray[0].toUpperCase()
  strtoarray.push((strtoarray[0].toUpperCase()));
  strtoarray.shift(strtoarray[0]);
  strtoarray.reverse();
  let str1 = strtoarray.toString();
  return func(str1)
}
console.log(firstWordUpperCase("Omri Uday", addlength));
function addlength(str1) {
  return str1.length;
}
function add(num1, num2) {
  return num1 + num2
}
function multy(num1, num2, add) {
  let sum = num1 * num2
  return add(sum, num1)
}
console.log(multy(1, 2, add))
