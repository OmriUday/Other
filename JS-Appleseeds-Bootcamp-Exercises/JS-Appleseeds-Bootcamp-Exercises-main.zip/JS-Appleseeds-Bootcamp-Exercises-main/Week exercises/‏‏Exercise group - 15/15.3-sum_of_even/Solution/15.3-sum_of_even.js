//1.
//The problem is in the lines: 12

//2.
//I found the bug with the dev tool I developed in Google Chrome.

//3.
//The problem occurred due to the fact that the index is incorrect according to what the user wants to happen in the function (connect the even numbers) at the moment it connects the odd numbers

//4.
function getSumOfEven(arr){
 return arr[1] + arr[3] + arr[5] + arr[7] + arr[9];
}
getSumOfEven([1,2,3,4,5,6,7,8,9,10]);