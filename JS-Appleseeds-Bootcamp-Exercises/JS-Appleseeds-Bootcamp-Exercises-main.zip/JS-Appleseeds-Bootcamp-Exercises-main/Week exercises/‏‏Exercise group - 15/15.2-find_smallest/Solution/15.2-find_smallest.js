//1.
//The problem is in the lines: 11 , 20

//2.
//I found the bug with the dev tool I developed in Google Chrome.

//3.
//The problem occurred due to the fact that the call to the function and the function itself are not called by the same names, in addition, the function does exactly the opposite action that its writer wanted from it

//4.
function findBigest(a, b, c){
 if (a > b > c){
 return c;
 } else if (a > c > b) {
 return a;
} else {
 return b;
 }
}
console.log(findBigest(52,66,2));