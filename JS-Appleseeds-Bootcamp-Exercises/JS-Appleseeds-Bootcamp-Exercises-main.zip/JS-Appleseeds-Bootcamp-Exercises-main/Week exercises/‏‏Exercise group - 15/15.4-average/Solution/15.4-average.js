//1.
//The problem is in the lines: 14 , 16

//2.
//I found the bug with the dev tool I developed in Google Chrome.

//3.
//The problem occurred due to the fact that There is a no setting sum variable and it gives ERROR in the program

//4.
function calcAverage (arr){
var sum ;
for ( var i = 0 ; i < arr .length; i ++ ){
sum += arr [ i ];
}
return sum / arr.length ;
}
calcAverage ([ 85 , 90 , 92 ]);