//1.
// This line is the problem because it is not separated by "," between the 2 different arrays , In addition, there is another problem in row 12 when the variable sum is set as a fixed variable, and then in row 14 you try to change it and it is not possible to change a fixed variable:
//getSum([1, 2, 3][5, 66, 23]);

//2.
//I found the bug with the dev tool I developed in Google Chrome.

//3.
// This line is the problem because it is not separated by "," between the 2 
// different arrays , In addition, there is another problem in row 12 when the 
// variable sum is set as a fixed variable, and then in row 14 you try to change it and it is not possible to change a fixed variable:

//4.
function getSum(arr1, arr2){
let sum = 0;
for (let i=0; i < arr1.length; i++){
sum += arr1[i];
}
for (let i=0; i < arr2.length; i++){
sum += arr2[i];
}
}
getSum([1,2,3],[5,66,23]);