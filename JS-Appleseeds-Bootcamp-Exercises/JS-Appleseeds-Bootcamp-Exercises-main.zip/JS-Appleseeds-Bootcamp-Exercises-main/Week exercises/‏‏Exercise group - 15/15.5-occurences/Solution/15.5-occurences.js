//1.
//The problem is in the lines: 13 , 14

//2.
//I found the bug with the dev tool I developed in Google Chrome.

//3.
//The problem occurred due to the fact that There are too many spaces in the lines I mentioned, and that flips the program.

//4.
function countOccurrences (str, char){
let counter = 0 ;
for ( let i = 0 ; i < str.length; i ++ ){
if ( str.charAt(i) === char ){
counter + 1 ;
}
}
return counter ;
}
countOccurrences ( "ini mini miny moe" , "n" );