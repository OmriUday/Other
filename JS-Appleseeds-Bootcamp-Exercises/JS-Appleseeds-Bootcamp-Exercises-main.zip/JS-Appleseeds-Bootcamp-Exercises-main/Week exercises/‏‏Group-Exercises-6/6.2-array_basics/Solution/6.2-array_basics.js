//////6.2/////
//1)
const people = ["Greg", "Mary", "Devon", "James"];
function Arry(arr) {
  for (let i = 0; i < arr.length; i++) {
    console.log(arr[i]);
  }
}
//test
Arry(people);

//2)
people.splice(people.indexOf("Greg"), 1);
//test
console.log(people);

//3)
people.splice(people.indexOf("James"), 1);
//test
console.log(people);

//4)
people.splice(0, 0, "Matt");
//test
console.log(people);

//5)
people.push("Omri");
//test
console.log(people);

//6)
for (let i = 0; i < people.length; i++) {
  console.log(people[i]);
  if (people[i] === "Mary") {
    i = people.length;
  }
}

//7)

