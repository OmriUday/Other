const arr = [1, 7, 3, 0, -5, 7, 3, 9];
for (i = 0; i < arr.length; i++) {
  console.log(arr[i]);
}

const arr = [1, 7, 3, 0, -5, 7, 3, 9];
function arrayLength(arr) {
  let counter = 0
  for (let i = 0; arr[i] == undefined; i++) {

    counter = i;
  }
  console.log(counter);
}
//test
arrayLength(arr);

const arr = [1, 7, 3, 0, -5, 7, 3, 9];
function arraySum(arr) {
  for (i = 0, sum = 0; i <= (arr.lenght) - 1; i++) {
    sum = sum + arr[i];
  }
  console.log(sum);
}
//test
arraySum();

const arr = [1, 7, 3, 0, -5, 7, 3, 9];
function arraySum(arr) {
  for (i = 0, sum = 0; i <= (arr.lenght) - 1; i++) {
    sum = sum + arr[i + 1] * arr[i];
  }
  console.log(sum);
}
//test
arraySum();


