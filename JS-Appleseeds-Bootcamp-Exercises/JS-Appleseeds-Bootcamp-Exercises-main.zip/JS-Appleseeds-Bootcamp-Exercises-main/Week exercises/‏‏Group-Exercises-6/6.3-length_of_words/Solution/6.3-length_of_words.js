///////6.3//////
function lengthOfStrings(arr) {
  let lettersCounter = [];
  for (i = 0; i < arr.length; i++) {
    lettersCounter[i] = arr[i].length;
  }
  return lettersCounter;
}
//test
const check = ['Hello', 'my', 'name', 'is', 'Omri'];
console.log(lengthOfStrings(check));