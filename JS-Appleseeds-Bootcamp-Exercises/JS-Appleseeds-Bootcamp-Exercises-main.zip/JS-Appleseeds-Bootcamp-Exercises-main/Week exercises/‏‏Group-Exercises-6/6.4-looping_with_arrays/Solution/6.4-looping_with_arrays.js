///////6.4//////
const worldPop = 7905614489;
function percentOfWorld(population) {
  return (population / worldPop) * 100;
}
function populationPercentage(arr) {
  let percentages = [];
  for (let i = 0; i < arr.length; i++) {
    percentages.push(percentOfWorld(arr[i]));
    let description = ['% of Italy:', '% of France:', '% of USA:', '% of Israel:']
    console.log(description[i], percentages[i]);
  }
}
//test
populationPercentage([60344172, 65464591, 333569543, 9200000]);