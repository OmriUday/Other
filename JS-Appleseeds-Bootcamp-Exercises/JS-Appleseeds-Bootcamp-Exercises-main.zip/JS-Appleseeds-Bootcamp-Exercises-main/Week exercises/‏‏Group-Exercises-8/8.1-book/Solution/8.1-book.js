const book = {
  bookName: "The Good Life!",
  authorName: "Omri Uday",
  published: "2021",
  genre: "Fantasy and adventure",
};

function bookDescription(Book) {
  console.log(`The book "${Book.bookName}" was written by ${Book.authorName} in the year ${Book.published} and the genre to which he belongs is - ${Book.genre}`);
}
//test
bookDescription(book);
