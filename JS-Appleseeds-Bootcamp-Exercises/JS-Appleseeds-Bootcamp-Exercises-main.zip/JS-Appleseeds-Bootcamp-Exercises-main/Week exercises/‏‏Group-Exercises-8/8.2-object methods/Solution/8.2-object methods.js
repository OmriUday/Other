const mycountry = {
  country: 'Israel',
  capital: 'Jerusalem ',
  language: 'Hebrew',
  population: '9.2',
  neighbours: ['Jordan', 'Egypt', 'Syria', 'Lebanon'],
}

mycountry.describe = function () {
  console.log(`${this.country} has ${this.population} million people, their mother tongue is ${this.language}, they have ${this.neighbours.length} neighbouring countries and a capital called ${this.capital}.`);
}
//test
mycountry.describe();
console.log(mycountry);

mycountry.checkIsland = function () {
  if (mycountry.neighbours.length > 0) {
    this.isIsland = false;
  }
  else {
    this.neighbours = true;
  }
}
//test
mycountry.checkIsland();
console.log(mycountry);