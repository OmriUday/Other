const getNumberOfAs = (s,n) => {



}

getNumberOfAs('abcdabcda')