const book1 = {
  name: 'First Book',
  author: 'Omri',
  year: '1994',
};

const book2 = {
  name: 'Second book',
  author: 'Uday',
  year: '2021',
};

const bookUtils = {
};

bookUtils.getFirstPublished = function (argument1, argument2) {
  if (argument1.year > argument2.year) {
    return argument2;
  }
  else {
    return argument1;
  }
};

bookUtils.setNewEdition = function (Book, Year) {
  Book.latestEdition = Year;
  return Book;
};

bookUtils.setLanguage = function (Book, Language) {
  Book.language = Language;
  return Book;
};

bookUtils.setTranslation = function (Book, Language, Translator) {
  const translatorObj = {
    language: 'Language',
    translator: 'Translator',
  }
  Book.translator = translatorObj;
  return Book;
};

bookUtils.setPublisher = function (Book, Name, Location) {
  const publisherObj = {
    name: 'Name',
    location: 'Location',
  }
  Book.publisher = publisherObj;
  return Book;
};

bookUtils.isSamePublisher = function (Book1, Book2) {
  if (Book1.publisher == Book2.publisher) {
    console.log("Yes, both the publisher and the location are the same in both books")
  }
  else {
    console.log("No, the publisher and the location are not the same in both books");
  }
};