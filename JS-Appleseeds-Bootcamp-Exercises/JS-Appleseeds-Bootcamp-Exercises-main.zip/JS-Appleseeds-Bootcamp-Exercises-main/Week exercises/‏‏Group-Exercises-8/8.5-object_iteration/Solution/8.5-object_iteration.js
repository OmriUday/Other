const myObject = {
  key1: 'value1',
  key2: 'value2',
  key3: 'value3',
  key4: 'value4',
  key5: 'value5',
};

function swap(Obj) {
  const newObj = {};
  let i = 0;
  const arr = [Object.keys(myObject)];
  const arr1 = [Object.values(myObject)];
  while (i < arr.length) {
    newObj.arr1[i] = arr[i];
    i++;
  }
  console.log(newObj);
}

swap(myObject);