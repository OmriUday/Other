//a//
const foods = ["falafel", "sabich", "hummus", "pizza with extra pineapple"];
//a.1
const ascending1 = foods.sort();
console.log(ascending1); //test

//a.2
const descending1 = foods.sort((a,b) => {
  if (a > b) return -1;
  if (a < b) return 1;
  return 0;
});
console.log(descending1); //test

//b//
const foodsWithUpperCase =[
  "falafel","Sabich","hummus","pizza with extra pineapple",];

 //b.1
 foods2 = foodsWithUpperCase.sort((a, b) => {
  let lowerA = a.toLowerCase();
  let lowerB = b.toLowerCase();
  if (lowerA > lowerB) return 1;
  if (lowerA < lowerB) return -1;
  return 0;
});
console.log(foods2); //test

// b.2
foods2 = foodsWithUpperCase.sort((a, b) => {
  let lowerA = a.toLowerCase();
  let lowerB = b.toLowerCase();
  if (lowerA < lowerB) return 1;
  if (lowerA > lowerB) return -1;
  return 0;
});
console.log(foods2); //test

//c//
const words = [
  "apple", "supercalifragilisticexpialidocious","hi", "zoo"];

//c.1
const longestToshortest  = words.sort((a, b) => b.length - a.length);
console.log(longestToshortest); //test