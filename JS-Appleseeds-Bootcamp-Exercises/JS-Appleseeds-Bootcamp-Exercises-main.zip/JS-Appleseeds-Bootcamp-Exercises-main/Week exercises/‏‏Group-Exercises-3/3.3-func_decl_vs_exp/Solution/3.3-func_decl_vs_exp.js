/////////3.3////////
//1,2,3)
const percentageOfWorld1 = n => (n/7900000000)*100;
//check
let percentOfItaly = percentageOfWorld1 (60344172) ;
console.log("For Italy - " + percentOfItaly);

let percentOfFrance = percentageOfWorld1 (65464591) ;
console.log("For France - " + percentOfFrance);

let percentOfUsa = percentageOfWorld1 (333569543) ;
console.log("For USA - " + percentOfUsa);


//4)
function percentageOfWorld2 (num1,num2,num3) {
  let res1 = (num1/7900000000)*100;
  let res2 = (num2/7900000000)*100;
  let res3 = (num3/7900000000)*100;

  return([res1 ,res2 , res3])
}
//check
let Italy = 60344172
let France = 65464591
let USA = 333569543;

console.log(percentageOfWorld2(Italy,France,USA));


