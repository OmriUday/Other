////////////3.1////////////
// From function declarations to function expressions
const welcomeMassage = function welcome() {
    let welcome = 'Welcome to Appleseeds Bootcamp!';
    return welcome;
}
//check
console.log(welcomeMassage());


const resPower = function power(a) {
    let myNumber = a;
    let result = Math.pow(myNumber, 2);
    return result;
}
//check//
console.log(resPower(6));


const resAdd = function add(a, b = 5) {
    let myNumber = a;
    let sum = myNumber + b;
    return sum;
}
//check
console.log(resAdd(4 , 9));


// From function expressions to function declarations
function hello () {
    let hello = "Hello!";
    return hello;
}
//check
console.log(hello());


function squareroot (x) {
    let res = Math.sqrt(x);
    return res;
}
//check
console.log(squareroot(16));


function randomnumbers ( x , y) {
    let res = (Math.random() * (x-y) + y)
    return res;
}
//check
console.log(randomnumbers( 2 , 4))