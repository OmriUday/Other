/////////3.2////////
// From function declarations to explicit and implicit return functions (one of each).
//explicit
const welcome = () => {
    let welcome = 'Welcome to Appleseeds Bootcamp!';
    return welcome;
}
//check
console.log(welcome());

//implicit
const welcome = () => "Welcome to Appleseeds Bootcamp!";
//check
console.log(welcome());


//explicit
const power = (a) => {
    let myNumber = a;
    let result = Math.pow(myNumber, 2);
    return result;
}
//check
console.log(power(5))

//implicit
const power = (a) => Math.pow(a,2);
//check
console.log(power(5))



// From function expressions to IIFE functions.
(a => Math.sqrt(a))();
//check
console.log((a => Math.sqrt(25))());


((a,b) => Math.random()*(a-b)+b)();
//check
console.log(((a,b) => Math.random()*(9-7)+7)());