// Select small pictures :
let pic1 = document.getElementById('pic1');
let pic2 = document.getElementById('pic2');
let pic3 = document.getElementById('pic3');
let pic7 = document.getElementById('pic7');
let pic8 = document.getElementById('pic8');
let pic9 = document.getElementById('pic9');
// Select big pictures :
let pic = document.getElementById('pic');

// Change zoon photo :
pic1.addEventListener('mouseover', function () {
  pic.src = "/Assets/Images/Monapoly_Item/Second_Picture2big.jpg";
});
pic2.addEventListener('mouseover', function () {
  pic.src = "/Assets/Images/Monapoly_Item/Display_Image1.jpg";
});
pic3.addEventListener('mouseover', function () {
  pic.src = "/Assets/Images/Monapoly_Item/more3.2.jpg";
});
pic7.addEventListener('mouseover', function () {
  pic.src = "/Assets/Images/Monapoly_Item/more2.2.jpg";
});
pic8.addEventListener('mouseover', function () {
  pic.src = "/Assets/Images/Monapoly_Item/Third image2big.jpg";
});
pic9.addEventListener('mouseover', function () {
  pic.src = "/Assets/Images/Monapoly_Item/more4.2.jpg";
});

// Select cart + orange number
let cart_number = document.querySelector('#cart_number');
const addToCart = document.querySelector('#addToCart');

// Make Event - Orange Number
let counter = 10;
addToCart.addEventListener('click', function () {
  counter++;
  cart_number.innerText = counter;
})

// 4 stars and above - (Part 4)
// Make Event - Carousel - 1
// Select Cards
let card7 = document.querySelector('.card7');
let card6 = document.querySelector('.card6');
let card5 = document.querySelector('.card5');
let card4 = document.querySelector('.card4');
let card3 = document.querySelector('.card3');
let card2 = document.querySelector('.card2');
let card1 = document.querySelector('.card1');

// Select Arrows
let leftClick1 = document.querySelector('.rightClick');
let rightClick1 = document.querySelector('.leftClick');


// Left Button 1
let y = 7;
let i = 0;
leftClick1.addEventListener('mouseup', function () {
  if (y === 0) {
    y = 7;
    i = 0;
  }
  else if (y === 7) {
    card7.style.display = 'block';
    card1.style.display = 'none';
    y--;
    i++;
  }
});

// Make Event - Carousel - 1
// Right Button 1
// rightClick1.addEventListener('mouseup', function () {
//   let q = 7;
//   let w = 0;
//   if (w === q) {
//     q = 7;
//     w = 0;
//   }
//   else if (q === 7) {
//     card1.style.display = 'block';
//     card7.style.display = 'none';
//     q++;
//     w--;
//   }
//   else if (w === 6) {
//     card2.style.display = 'block';
//     card6.style.display = 'none';
//     q++;
//     w--;
//   }
//   else if (w === 5) {
//     card3.style.display = 'block';
//     card5.style.display = 'none';
//     q++;
//     w--;
//   }
// });

// Featured items you may like (Part 5)
// Make Event - Carousel - 2
// Select Cards2
let card14 = document.querySelector('.card14');
let card13 = document.querySelector('.card13');
let card12 = document.querySelector('.card12');
let card11 = document.querySelector('.card11');
let card10 = document.querySelector('.card10');
let card9 = document.querySelector('.card9');
let card8 = document.querySelector('.card8');

// Select Arrow2
let leftClick2 = document.querySelector('#leftClick');
let rightClick2 = document.querySelector('#rightClick');

// Make Event Left Button 2
leftClick2.addEventListener('mouseup', function () {
  let k = 7;
  let j = 0;
  if (j === k) {
    k = 7;
    j = 0;
  }
  else if (k === 7) {
    card14.style.display = 'block';
    card8.style.display = 'none';
    k--;
    j++;
  }
  else if (k === 6) {
    card13.style.display = 'block';
    card9.style.display = 'none';
    k--;
    j++;
  }
  else if (k === 5) {
    card12.style.display = 'block';
    card10.style.display = 'none';
    k--;
    j++;
  }
});

// Right Button 2
// rightClick1.addEventListener('mouseup', function () {
//   let q = 7;
//   let w = 0;
//   if (w === q) {
//     q = 7;
//     w = 0;
//   }
//   else if (q === 7) {
//     card1.style.display = 'block';
//     card7.style.display = 'none';
//     q++;
//     w--;
//   }
//   else if (w === 6) {
//     card2.style.display = 'block';
//     card6.style.display = 'none';
//     q++;
//     w--;
//   }
//   else if (w === 5) {
//     card3.style.display = 'block';
//     card5.style.display = 'none';
//     q++;
//     w--;
//   }
// });

