const body = document.querySelector('body');

const new_h1 = document.createElement('h1');
new_h1.innerText = 'Hello This is my practice that will makes me perfect !'
body.appendChild(new_h1);
new_h1.classList.add('new_h1');
new_h1.style.color = 'blue';

const new_h2 = document.createElement('h2');
new_h2.innerText = 'This is my Sub-Title'
body.appendChild(new_h2);
new_h2.classList.add('new_h2');
new_h2.style.color = 'pink';

const new_h3 = document.createElement('h3');
new_h3.innerText = 'Let me introduce you to Lorem :'
body.appendChild(new_h3);
new_h3.classList.add('new_h3');
new_h3.style.color = 'green';

const new_p = document.createElement('p');
new_p.innerText = 'Lorem ipsum dolor sit amet consectetur adipisicing elit.Corrupti quam iure perferendis repudiandae totam praesentium nostrum dicta nam eos doloremque dolores exercitationem natus iusto nobis labore harum, earum saepe, incidunt omnis quisquam debitis odio quod! Voluptatibus autem, sed vel et reiciendis odio magnam aspernatur minima ducimus reprehenderit repudiandae doloribus ? Ea nihil vitae veniam odio obcaecati, eveniet at explicabo exercitationem magnam repellendus est, animi totam tempora assumenda natus sit.Commodi sed voluptatibus magnam! Ex maiores odit consequuntur iste! Maxime inventore omnis at, corrupti modi unde expedita impedit vitae, explicabo ducimus consectetur officia nobis eius maiores nam ratione aperiam totam doloribus aliquid.Perspiciatis praesentium obcaecati repellat, porro nam ducimus! Delectus doloremque velit, iusto soluta cumque accusamus odit eius.Ut reiciendis facere unde cum perspiciatis eligendi, error iste perferendis et accusamus tempore atque repellendus esse assumenda officiis mollitia sed id odit.Fugit cupiditate eos, minus quo recusandae eaque, voluptatem totam, soluta libero iste repellendus tenetur aspernatur magnam impedit doloremque saepe consequuntur enim.At voluptatum pariatur quis velit reiciendis quibusdam perspiciatis officia debitis voluptas eaque ? Accusamus nobis, consequatur voluptatem, impedit tempore iure non quae praesentium, cumque id tempora ? Beatae, quae deleniti ? Ab doloremque labore officiis suscipit cum ipsam iusto, nulla voluptates architecto quisquam ? Quam facilis exercitationem obcaecati alias neque.Pariatur quo, recusandae repudiandae fuga expedita eos nobis eius autem iusto provident aut ducimus libero assumenda odio suscipit obcaecati.Fuga quae impedit, itaque vel, odio minima perferendis, adipisci repellendus ducimus dolore labore ea excepturi.Inventore maxime ipsa mollitia laboriosam veniam dolor aperiam aspernatur saepe.Dolor sit odio natus necessitatibus! Molestias fuga tenetur, iste incidunt aliquid fugit qui nesciunt, dolor unde autem eius, saepe facilis modi rerum est quo! Esse corrupti fuga impedit ducimus ? Dignissimos distinctio rem ducimus voluptates neque, aperiam praesentium laborum veritatis ratione, sequi repudiandae amet quidem quibusdam illum maxime magni debitis, ea enim.Cupiditate id assumenda atque enim hic fugiat, vel quibusdam! Nobis quibusdam laborum velit accusantium est consectetur, cupiditate ipsa iure molestiae suscipit repellendus sequi, dolore culpa harum iusto temporibus incidunt neque exercitationem, possimus delectus dolores maiores unde itaque.Maiores provident excepturi, officiis unde corporis, molestias repellat aliquid soluta consequatur fugit aperiam ab nostrum! Exercitationem velit expedita in facere magnam error dignissimos aliquam provident iusto repudiandae.Officia modi perspiciatis aperiam voluptatibus veniam itaque! Atque, omnis expedita.Praesentium magni excepturi libero debitis id, dolorem expedita animi earum hic voluptates suscipit soluta nesciunt pariatur perspiciatis distinctio cum omnis ratione eos laudantium quis dicta neque ?'
body.appendChild(new_p);
new_p.classList.add('new_p');
new_p.style.backgroundColor = 'orange';
new_p.style.fontWeight = 'bold';
new_p.style.fontSize = '22px';






