const submit = document.getElementById('submit');
let input = document.getElementById('text');
let p = document.querySelector('p');
p.addEventListener('input', (updateValue) => {
});
